# burner-assembling-machine
Factorio mod that adds a 1-ingredient slow burner assembler.
